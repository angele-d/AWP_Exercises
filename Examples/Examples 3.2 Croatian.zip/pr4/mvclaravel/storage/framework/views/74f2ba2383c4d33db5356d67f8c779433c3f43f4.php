<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Prijave</h1>
    </div>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Ime i prezime</th>
            <th>Email</th>
            <th>Smjer</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($prijave as $prijava): ?>
        <tr>
            <th><?php echo htmlspecialchars($prijava['name']) ?></th>
            <th><?php echo htmlspecialchars($prijava['email']) ?></th>
            <th><?php echo htmlspecialchars($prijava['academy_major']) ?></th>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>