@extends('layouts.app')

@section('content')
    <div class="page-header">
       <h1>PHP</h1>
    </div>
    
    <p>
        Kroz predavanja ćemo sve polaznike pripremiti za rad na praktičnim projektima.
    </p>
    
    
    <p>
        Vježbe su koncipirane da se kroz njih uči i radi. Kroz sve vježbe će se raditi s vama kako bi svi mogli jednako
        kvalitetno pratiti predavanja.
    </p>

    <p><img src="{{asset('logo.png')}}"/></p>
@endsection
