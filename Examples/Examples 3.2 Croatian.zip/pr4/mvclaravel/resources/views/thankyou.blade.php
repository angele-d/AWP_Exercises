@extends('layouts.app')

@section('content')
    <p>Hvala na prijavi !!</p>
@endsection
