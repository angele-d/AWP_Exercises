-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2017 at 10:40 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendee`
--

CREATE TABLE `attendee` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `academy_major` varchar(255) NOT NULL,
  `academy_year` varchar(255) NOT NULL,
  `motivation` varchar(1000) NOT NULL,
  `prior_knowledge` varchar(1000) NOT NULL,
  `prior_language` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendee`
--

INSERT INTO `attendee` (`id`, `name`, `email`, `academy_major`, `academy_year`, `motivation`, `prior_knowledge`, `prior_language`) VALUES
(1, 'Ivo', 'ivo2@etf.hr', 'Auto', '3', 'dsa', 'da', 'C#'),
(2, 'Stanko', 'stanko@etfos.hr', 'Računarstvo', '4', 'Učenje', 'Da', 'C,C#'),
(4, 'Mirko', 'mirkovicmirko@net.hr', 'Komunikacije', '2', 'Novo iskustvo', 'Ne', 'C,Javascript'),
(5, 'Ana Anić', 'aanic@etfos.hr', 'Računarstvo', '5', 'Stjecanje iskustva', 'Da', 'C#,Javascript');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendee`
--
ALTER TABLE `attendee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendee`
--
ALTER TABLE `attendee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
