<?php

/**
 * example config file
 */
return [
    //'some_config_key' => 'some config value',

    'url'           => 'http://localhost/mvc/',
    'mode'          => 'development',

    'admin_email'   => 'student@etfos.hr',
    'admin_password' => 'student',

    'db_name'       => 'mvc',
    'db_user'       => 'root',
    'db_password'   => '',
];