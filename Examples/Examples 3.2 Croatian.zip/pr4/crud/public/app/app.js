var app = angular.module('employeeRecords', [])
        .constant('API_URL', 'http://localhost/crud/public/api/v1/');