<?php 
//IP Geolocation request
function show_ip_info($ip) { 
    
    //URL na koji se spajamo
    $url = 'http://freegeoip.net/csv/' . $ip;
    
    //Otvori konekciju
    $fp = fopen($url, 'r');

    //dohvati podatke
    $read = fgetcsv($fp);
    
    //var_dump($read);

    //Zatvori konekciju
    fclose($fp);

    //Ispis podatka
    echo "<p>IP Adresa: $ip<br>
    Zemlja: $read[2]<br>
    Grad: $read[5], $read[3]<br>
    Zemljopisna širina: $read[7]<br>
    Zemljopisna dužina: $read[8]</p>";

} 

//Klijentova IP adresa
echo '<h2>Informacije o Vama</h2>';
show_ip_info($_SERVER['REMOTE_ADDR']);

//Informacije o nekoj stranici
$url = 'www.etfos.unios.hr';
echo "<h2>Informacije o $url</h2>";
show_ip_info(gethostbyname($url));

//Informacije o nekoj stranici
$url = 'www.google.com';
echo "<h2>Informacije o $url</h2>";
show_ip_info(gethostbyname($url));

?>
