'1', '', '2017-02-07 09:02:31', 'Post 1', 'post-1', '<p><img alt=\"\" src=\"https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQcsDolEhLq4J5erqVJhzAv-qeU-hJ6R5Ez7SoFSmR0J3SlzuoMrg\" style=\"float:left; height:128px; width:128px\" /></p>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla erit controversia. Occultum facinus esse potuerit, gaudebit; Velut ego nunc moveor. Et quidem, inquit, vehementer errat;</p>

<p>Quid me istud rogas? Ita prorsus, inquam; Tollenda est atque extrahenda radicitus.</p>
', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut in geometria, prima si dederis, danda sunt omnia. Nam quibus rebus efficiuntur voluptates, eae non sunt in potestate sapientis. Duo Reges: constructio interrete. Idem iste, inquam, de voluptate quid sentit? Ab his oratores, ab his imperatores ac rerum publicarum principes extiterunt. Sed ad bona praeterita redeamus.</p>

<p>Quid de Pythagora? Quorum altera prosunt, nocent altera. Quod ea non occurrentia fingunt, vincunt Aristonem; Haec para/doca illi, nos admirabilia dicamus. Expectoque quid ad id, quod quaerebam, respondeas. Neminem videbis ita laudatum, ut artifex callidus comparandarum voluptatum diceretur.</p>

<pre>
<code class=\"language-php\">protected function getUserByRecaller($recaller)
{
    if ($this-&gt;validRecaller($recaller) &amp;&amp; ! $this-&gt;tokenRetrievalAttempted)
    {
        $this-&gt;tokenRetrievalAttempted = true;

        list($id, $token) = explode(\"|\", $recaller, 2);

        $this-&gt;viaRemember = ! is_null($user = $this-&gt;provider-&gt;retrieveByToken($id, $token));

        return $user;
    }
}</code></pre>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut proverbia non nulla veriora sint quam vestra dogmata. Cur iustitia laudatur? Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Quare si potest esse beatus is, qui est in asperis reiciendisque rebus, potest is quoque esse. Virtutibus igitur rectissime mihi videris et ad consuetudinem nostrae orationis vitia posuisse contraria. Duo Reges: constructio interrete. Huius, Lyco, oratione locuples, rebus ipsis ielunior. Hinc ceteri particulas arripere conati suam quisque videro voluit afferre sententiam. Videsne quam sit magna dissensio?</p>

<p>Et hunc idem dico, inquieta sed ad virtutes et ad vitia nihil interesse. Ut proverbia non nulla veriora sint quam vestra dogmata. Quis non odit sordidos, vanos, leves, futtiles? At iam decimum annum in spelunca iacet. Praeteritis, inquit, gaudeo. Si quae forte-possumus. Cur post Tarentum ad Archytam? Honesta oratio, Socratica, Platonis etiam. Non risu potius quam oratione eiciendum? An vero, inquit, quisquam potest probare, quod perceptfum, quod.</p>
', '0', '1', '1', 
'2', '', '', 'Post 2', 'post-2', '<img alt=\"\" src=\"/files/user2/goomba.png\" style=\"float:left; height:128px; width:128px\" /><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Et nemo nimium beatus est; Non quam nostram quidem, inquit Pomponius iocans; De vacuitate doloris eadem sententia erit. Ipse Epicurus fortasse redderet, ut Sextus Peducaeus, Sex. Sextilio Rufo, cum is rem ad amicos ita deferret, se esse heredem Q. Duo Reges: constructio interrete. Itaque rursus eadem ratione, qua sum paulo ante usus, haerebitis. </p>

<p>Cuius quidem, quoniam Stoicus fuit, sententia condemnata mihi videtur esse inanitas ista verborum. Sed eum qui audiebant, quoad poterant, defendebant sententiam suam. Idemque diviserunt naturam hominis in animum et corpus. Item de contrariis, a quibus ad genera formasque generum venerunt. Hoc etsi multimodis reprehendi potest, tamen accipio, quod dant. Utilitatis causa amicitia est quaesita. Atqui haec patefactio quasi rerum opertarum, cum quid quidque sit aperitur, definitio est. Cur ipse Pythagoras et Aegyptum lustravit et Persarum magos adiit? </p>

', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dic in quovis conventu te omnia facere, ne doleas. Quae contraria sunt his, malane? An me, inquis, tam amentem putas, ut apud imperitos isto modo loquar? Qui autem esse poteris, nisi te amor ipse ceperit? Duo Reges: constructio interrete. Verba tu fingas et ea dicas, quae non sentias? </p>

<p>Tum ille timide vel potius verecunde: Facio, inquit. Callipho ad virtutem nihil adiunxit nisi voluptatem, Diodorus vacuitatem doloris. Non laboro, inquit, de nomine. Ab hoc autem quaedam non melius quam veteres, quaedam omnino relicta. Vulgo enim dicitur: Iucundi acti labores, nec male Euripidesconcludam, si potero, Latine; </p>

<p>Hoc est non dividere, sed frangere. Ita redarguitur ipse a sese, convincunturque scripta eius probitate ipsius ac moribus. Unum est sine dolore esse, alterum cum voluptate. Cur igitur, inquam, res tam dissimiles eodem nomine appellas? Et quod est munus, quod opus sapientiae? Tum ille timide vel potius verecunde: Facio, inquit. Negare non possum. Cyrenaici quidem non recusant; Non igitur de improbo, sed de callido improbo quaerimus, qualis Q. <a href=\'http://loripsum.net/\' target=\'_blank\'>Quis est tam dissimile homini.</a> </p>

<p>Quod non faceret, si in voluptate summum bonum poneret. Erat enim Polemonis. Id est enim, de quo quaerimus. </p>

<p>Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Hanc quoque iucunditatem, si vis, transfer in animum; Illud dico, ea, quae dicat, praeclare inter se cohaerere. De vacuitate doloris eadem sententia erit. Non enim iam stirpis bonum quaeret, sed animalis. Quae duo sunt, unum facit. <a href=\'http://loripsum.net/\' target=\'_blank\'>Age sane, inquam.</a> Hic ego: Pomponius quidem, inquam, noster iocari videtur, et fortasse suo iure. Eadem nunc mea adversum te oratio est. Ita ceterorum sententiis semotis relinquitur non mihi cum Torquato, sed virtuti cum voluptate certatio. </p>

<p>Itaque vides, quo modo loquantur, nova verba fingunt, deserunt usitata. Deinde disputat, quod cuiusque generis animantium statui deceat extremum. Uterque enim summo bono fruitur, id est voluptate. Sin tantum modo ad indicia veteris memoriae cognoscenda, curiosorum. Age, inquies, ista parva sunt. Et nemo nimium beatus est; Tum Piso: Quoniam igitur aliquid omnes, quid Lucius noster? Graecis hoc modicum est: Leonidas, Epaminondas, tres aliqui aut quattuor; </p>

<p>Hoc Hieronymus summum bonum esse dixit. Utilitatis causa amicitia est quaesita. Equidem etiam Epicurum, in physicis quidem, Democriteum puto. </p>

<p>Deinde disputat, quod cuiusque generis animantium statui deceat extremum. Non quam nostram quidem, inquit Pomponius iocans; Minime vero, inquit ille, consentit. Tecum optime, deinde etiam cum mediocri amico. Memini vero, inquam; Memini vero, inquam; </p>

', '0', '1', '2', 
'3', '', '', 'Post 3', 'post-3', '<img alt=\"\" src=\"/files/user2/rouge-shell.png\" style=\"float:left; height:128px; width:128px\" /><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. At hoc in eo M. Ergo hoc quidem apparet, nos ad agendum esse natos. Quaesita enim virtus est, non quae relinqueret naturam, sed quae tueretur. Duo Reges: constructio interrete. Quicquid enim a sapientia proficiscitur, id continuo debet expletum esse omnibus suis partibus; Ita enim vivunt quidam, ut eorum vita refellatur oratio. Numquam facies. Atqui reperies, inquit, in hoc quidem pertinacem; Quare conare, quaeso. </p>

<p>Quae similitudo in genere etiam humano apparet. Si enim ita est, vide ne facinus facias, cum mori suadeas. Huius, Lyco, oratione locuples, rebus ipsis ielunior. Quod totum contra est. At modo dixeras nihil in istis rebus esse, quod interesset. </p>

', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Traditur, inquit, ab Epicuro ratio neglegendi doloris. Ut in voluptate sit, qui epuletur, in dolore, qui torqueatur. Duo Reges: constructio interrete. Et quidem iure fortasse, sed tamen non gravissimum est testimonium multitudinis. Hoc enim constituto in philosophia constituta sunt omnia. Praeclare hoc quidem. Quae quidem vel cum periculo est quaerenda vobis; </p>

<p>Quamquam haec quidem praeposita recte et reiecta dicere licebit. Nondum autem explanatum satis, erat, quid maxime natura vellet. Quo plebiscito decreta a senatu est consuli quaestio Cn. Ita multo sanguine profuso in laetitia et in victoria est mortuus. Expectoque quid ad id, quod quaerebam, respondeas. Octavio fuit, cum illam severitatem in eo filio adhibuit, quem in adoptionem D. Nam adhuc, meo fortasse vitio, quid ego quaeram non perspicis. Nam illud vehementer repugnat, eundem beatum esse et multis malis oppressum. </p>

<p>Quae similitudo in genere etiam humano apparet. Iam in altera philosophiae parte. <a href=\'http://loripsum.net/\' target=\'_blank\'>Si id dicis, vicimus.</a> <a href=\'http://loripsum.net/\' target=\'_blank\'>Quis negat?</a> Itaque nostrum est-quod nostrum dico, artis est-ad ea principia, quae accepimus. Tu autem negas fortem esse quemquam posse, qui dolorem malum putet. Et quidem iure fortasse, sed tamen non gravissimum est testimonium multitudinis. Isto modo, ne si avia quidem eius nata non esset. Hoc dixerit potius Ennius: Nimium boni est, cui nihil est mali. Quid adiuvas? Quod non faceret, si in voluptate summum bonum poneret. </p>

<p>Estne, quaeso, inquam, sitienti in bibendo voluptas? Sin laboramus, quis est, qui alienae modum statuat industriae? <a href=\'http://loripsum.net/\' target=\'_blank\'>Hunc vos beatum;</a> <a href=\'http://loripsum.net/\' target=\'_blank\'>Que Manilium, ab iisque M.</a> Plane idem, inquit, et maxima quidem, qua fieri nulla maior potest. Etiam beatissimum? Sedulo, inquam, faciam. Quam illa ardentis amores excitaret sui! Cur tandem? Non enim, si omnia non sequebatur, idcirco non erat ortus illinc. </p>

<p>Ut pulsi recurrant? Amicitiam autem adhibendam esse censent, quia sit ex eo genere, quae prosunt. <a href=\'http://loripsum.net/\' target=\'_blank\'>Efficiens dici potest.</a> Sed ad haec, nisi molestum est, habeo quae velim. <a href=\'http://loripsum.net/\' target=\'_blank\'>Cui Tubuli nomen odio non est?</a> Eiuro, inquit adridens, iniquum, hac quidem de re; Quo modo autem philosophus loquitur? <a href=\'http://loripsum.net/\' target=\'_blank\'>Age sane, inquam.</a> Ecce aliud simile dissimile. Octavio fuit, cum illam severitatem in eo filio adhibuit, quem in adoptionem D. </p>

<p>Non dolere, inquam, istud quam vim habeat postea videro; Nos paucis ad haec additis finem faciamus aliquando; Vestri haec verecundius, illi fortasse constantius. Quos quidem tibi studiose et diligenter tractandos magnopere censeo. Sed residamus, inquit, si placet. Quid autem habent admirationis, cum prope accesseris? Paupertas si malum est, mendicus beatus esse nemo potest, quamvis sit sapiens. Id enim volumus, id contendimus, ut officii fructus sit ipsum officium. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Egone quaeris, inquit, quid sentiam? Eam stabilem appellas. </p>

<p>Quae cum dixisset paulumque institisset, Quid est? <a href=\'http://loripsum.net/\' target=\'_blank\'>Sed ad illum redeo.</a> Est, ut dicis, inquam. <a href=\'http://loripsum.net/\' target=\'_blank\'>At multis se probavit.</a> </p>

<p>Nos paucis ad haec additis finem faciamus aliquando; <a href=\'http://loripsum.net/\' target=\'_blank\'>Hunc vos beatum;</a> Recte dicis; Videamus animi partes, quarum est conspectus illustrior; Utinam quidem dicerent alium alio beatiorem! Iam ruinas videres. </p>

', '0', '1', '2', 
'4', '', '', 'Post 4', 'post-4', '<img alt=\"\" src=\"/files/user2/rouge-shyguy.png\" style=\"float:left; height:128px; width:128px\" /><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\'http://loripsum.net/\' target=\'_blank\'>Et nemo nimium beatus est;</a> Itaque a sapientia praecipitur se ipsam, si usus sit, sapiens ut relinquat. Duo Reges: constructio interrete. Quos quidem tibi studiose et diligenter tractandos magnopere censeo. At enim sequor utilitatem. Hoc ille tuus non vult omnibusque ex rebus voluptatem quasi mercedem exigit. <a href=\'http://loripsum.net/\' target=\'_blank\'>Quid vero?</a> </p>

<p>Aliena dixit in physicis nec ea ipsa, quae tibi probarentur; Est enim tanti philosophi tamque nobilis audacter sua decreta defendere. Nam de isto magna dissensio est. De vacuitate doloris eadem sententia erit. </p>

', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Stoici autem, quod finem bonorum in una virtute ponunt, similes sunt illorum; Quam si explicavisset, non tam haesitaret. </p>

<p>Cum praesertim illa perdiscere ludus esset. Quid est igitur, inquit, quod requiras? <a href=\'http://loripsum.net/\' target=\'_blank\'>Sed ad bona praeterita redeamus.</a> Ut optime, secundum naturam affectum esse possit. </p>

<p>Atque haec coniunctio confusioque virtutum tamen a philosophis ratione quadam distinguitur. Quae tamen a te agetur non melior, quam illae sunt, quas interdum optines. An ea, quae per vinitorem antea consequebatur, per se ipsa curabit? Cuius ad naturam apta ratio vera illa et summa lex a philosophis dicitur. Duo enim genera quae erant, fecit tria. Primum quid tu dicis breve? Res enim se praeclare habebat, et quidem in utraque parte. Multoque hoc melius nos veriusque quam Stoici. </p>

<p>At miser, si in flagitiosa et vitiosa vita afflueret voluptatibus. Negat esse eam, inquit, propter se expetendam. Quae sequuntur igitur? Sin laboramus, quis est, qui alienae modum statuat industriae? Praeclare hoc quidem. Videsne quam sit magna dissensio? </p>

<p>Negat esse eam, inquit, propter se expetendam. Inde sermone vario sex illa a Dipylo stadia confecimus. Quod autem satis est, eo quicquid accessit, nimium est; Utrum igitur tibi litteram videor an totas paginas commovere? Habes, inquam, Cato, formam eorum, de quibus loquor, philosophorum. <a href=\'http://loripsum.net/\' target=\'_blank\'>Quae cum essent dicta, discessimus.</a> </p>

<p>Non igitur potestis voluptate omnia dirigentes aut tueri aut retinere virtutem. Stoicos roga. <a href=\'http://loripsum.net/\' target=\'_blank\'>Cur iustitia laudatur?</a> Murenam te accusante defenderem. Equidem etiam Epicurum, in physicis quidem, Democriteum puto. <a href=\'http://loripsum.net/\' target=\'_blank\'>Urgent tamen et nihil remittunt.</a> </p>

<p>Animi enim quoque dolores percipiet omnibus partibus maiores quam corporis. Ita redarguitur ipse a sese, convincunturque scripta eius probitate ipsius ac moribus. <a href=\'http://loripsum.net/\' target=\'_blank\'>Quis enim redargueret?</a> <a href=\'http://loripsum.net/\' target=\'_blank\'>Non laboro, inquit, de nomine.</a> Et hunc idem dico, inquieta sed ad virtutes et ad vitia nihil interesse. Nec vero hoc oratione solum, sed multo magis vita et factis et moribus comprobavit. </p>

<p>Quae duo sunt, unum facit. Qui potest igitur habitare in beata vita summi mali metus? Indicant pueri, in quibus ut in speculis natura cernitur. Quid turpius quam sapientis vitam ex insipientium sermone pendere? Duo Reges: constructio interrete. </p>

', '0', '1', '2', 
