<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="col-sm-offset-2 col-sm-8">
			<div class="panel panel-default">
				<div class="panel-heading">
					Uredi zadatak
				</div>

				<div class="panel-body">
					<!-- Display Validation Errors -->
					<?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<!-- New Task Form -->
					<form action="<?php echo e(url('task/' . $task->id)); ?>" method="POST" class="form-horizontal">
						<?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('PATCH')); ?>

                                                
						<!-- Task Name -->
						<div class="form-group">
							<label for="task-name" class="col-sm-3 control-label">Naziv zadatka</label>

							<div class="col-sm-6">
								<input type="text" name="name" id="task-name" class="form-control" value="<?php echo e(old('task') ? old('task') : $task->name); ?>">
							</div>
						</div>
            
            	<!-- Task Description -->
						<div class="form-group">              
              <label for="task-description" class="col-sm-3 control-label">Opis zadatka</label>
              <div class="col-sm-6">
                  <input type="text" name="description" id="task-description" class="form-control" value="<?php echo e(old('task') ? old('task') : $task->description); ?>">
              </div>
						</div>

						<!-- Add Task Button -->
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-6">
								<button type="submit" class="btn btn-default">
									<i class="fa fa-btn fa-save"></i>Spremi
								</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>