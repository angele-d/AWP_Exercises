@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dobro došli</div>

                <div class="panel-body">
                    Ovo je stranica koja se otvara pri stvaranju nove aplikacije.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
