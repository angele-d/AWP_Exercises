Direktorij vendor je obrisan u oba primjera tako da oni neće raditi.

Potrebno je sa CLI otvoriti direktorij (npr. C:/xampp/htodcs/students)
i u CLI utipkati naredbu composer install

Naredba composer install će preuzeti novi vendor direktorij.

U direktoriju je dodan backup baze podataka koji možete postaviti ili 
možete pokrenuti migracije.

Ako mijenjate postavke kao što su baza podataka postaviti konfiguraciju u .env datoteci.